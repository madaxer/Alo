#!/usr/bin/env python3
"""Plain‑text docker‑compose assembler.

Reads:
  * a base file (plain text) that already contains 'services:' header
  * one or more module *.txt files whose first line is indented TWO spaces
    so their keys nest under the existing 'services:' key.
  * .env file at repo root for ${VAR} substitution

Writes:
  * docker‑compose.generated.txt  (plain text)
  * docker‑compose.generated.yml  (same content, .yml extension)

Example:
    python scripts/manage.py \
        --base base-compose.txt \
        --modules-dir modules \
        --modules multiplexor server
"""

import argparse, os, re, shutil
from pathlib import Path
from dotenv import load_dotenv

VAR_PATTERN = re.compile(r"\${([^}]+)}")

def subst_env(text: str) -> str:
    """Replace ${VAR} placeholders with values from environment."""
    return VAR_PATTERN.sub(lambda m: os.getenv(m.group(1), m.group(0)), text)

def assemble(base_file: Path, module_files: list[Path], out_prefix: Path):
    base_text = subst_env(base_file.read_text())
    parts: list[str] = [base_text.rstrip(), ""]  # ensure newline

    for mf in module_files:
        part = subst_env(mf.read_text().rstrip())
        parts.append(part)
        parts.append("")  # blank line between modules

    final_txt = "\n".join(parts)
    txt_path  = out_prefix.with_suffix(".txt")
    yml_path  = out_prefix.with_suffix(".yml")

    txt_path.write_text(final_txt)
    # copy/rename to .yml
    shutil.copyfile(txt_path, yml_path)
    print(f"✔  wrote {txt_path.relative_to(Path.cwd())} and {yml_path.name}")

def main():
    load_dotenv()  # .env in repo root
    p = argparse.ArgumentParser(description="Assemble compose from plain‑text fragments")
    p.add_argument("--base", required=True, help="base-compose.txt path")
    p.add_argument("--modules-dir", default="modules", help="directory with *.txt service fragments")
    p.add_argument("--modules", nargs="+", required=True, help="module names (files <name>.txt)")
    p.add_argument("--output", default="docker-compose.generated", help="output prefix without extension")
    args = p.parse_args()

    base_file = Path(args.base)
    mod_dir   = Path(args.modules_dir)
    module_files = [mod_dir / f"{name}.txt" for name in args.modules]
    missing = [str(m) for m in module_files if not m.exists()]
    if missing:
        p.error("Module files not found: " + ", ".join(missing))

    assemble(base_file, module_files, Path(args.output))

if __name__ == "__main__":
    main()