# TXT Compose Tool

**Version built**: 2025-04-22T13:19:54Z

This variant treats every compose fragment as **plain text**.

* `base-compose.txt` — contains your original YAML, including anchors.
  Must already include the `services:` key.
* `modules/<name>.txt` — start each module file with two spaces so it
  nests under the existing `services:` block.

Place a **.env** file in the repo root for `${VAR}` substitution.

## Quick start

```bash
pip install -r requirements.txt
python scripts/manage.py \
    --base base-compose.txt \
    --modules-dir modules \
    --modules multiplexor server
```

The script writes:

```
docker-compose.generated.txt
docker-compose.generated.yml   # same content, different suffix
```